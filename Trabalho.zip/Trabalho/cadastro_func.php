<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>-- Rede JBL --</title>
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">
  <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900|Raleway:400,300,700,900" rel="stylesheet">
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
</head>

<body >
    <?php
  include "menu_adm.php";

    ?></br>
    <div class="container text-center">
      <h1>CADASTRAR FUNCIONÁRIO</h1>
    </div>
    <!-- <div id="area-principal"> -->

			<!-- <div class="contato1"> -->
      </br>
      <div class="container text-center">
    <form class="form-contact" tabindex="1" action="envia.php" method="post"></form>
       <div class="col-lg-12 col-md-12 col-sm-8 col-xs-8"><input type="text" class="form-contact-input" name="nome" placeholder="Nome" required /></br></div>
       <div class="col-lg-12 col-md-12 col-sm-8 col-xs-8"><input type="email" class="form-contact-input" name="email" placeholder="Email" required /></br></div>
       <div class="col-lg-12 col-md-12 col-sm-8 col-xs-8"><input type="tel" class="form-contact-input" name="cpf" placeholder="CPF" /></br></div>
       <div class="col-lg-12 col-md-12 col-sm-8 col-xs-8"><input type="cpf" class="form-contact-input" name="tel" placeholder="Telefone" /></br></div>
       <div class="col-lg-12 col-md-12 col-sm-8 col-xs-8"><input type="password" class="form-contact-input" name="senha" placeholder="Senha" /></br></div>
       <div class="col-lg-12 col-md-12 col-sm-8 col-xs-8"><button type="submit" class="form-contact-button">Enviar</button></div>
       <div class="col-lg-12 col-md-12 col-sm-8 col-xs-8"><button type="reset" class="form-contact-button">Limpar</button></div>
</div>

				<?php
				include("conexao.php");
				if(isset($_POST['nome'])){
				$nome=$_POST['nome'];
				$senha=md5 ($_POST['senha']);
				$endereco=($_POST['endereco']);
				$cpf=$_POST['cpf'];

				$conexao= conecta_mysql();

				$sql="insert into alunos(nome,senha,cpf,endereco)
				values ('$nome','$senha','$cpf','$endereco')";

				if(mysqli_query($conexao,$sql)){
					echo "<div id='postagem'>";
					print "Aluno cadastrado com sucesso!";
					echo "</div>";
			}
			else{
				echo "<div id='postagem'>";
				echo "Erro ao cadastrar aluno!";
				echo "</div>";
			}
			}
				?>
			 <!-- Postagem-->


	</div> <!-- Area principal-->
</body>
</html>
