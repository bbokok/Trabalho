<form class="form-contact" tabindex="1" action="envia.php" method="post"></form>
<div class="container">
  <h1 class="texto"><center>Entre em contato...</center></h1></br>

  <div class="contato1">
<form class="form-contact" tabindex="1" action="envia.php" method="post"></form>
     <div class="col-lg-12 col-md-12 col-sm-8 col-xs-8"><input type="text" class="form-contact-input" name="nome" placeholder="Nome" required /></br></div>
     <div class="col-lg-12 col-md-12 col-sm-8 col-xs-8"><input type="email" class="form-contact-input" name="email" placeholder="Email" required /></br></div>
     <div class="col-lg-12 col-md-12 col-sm-8 col-xs-8"><input type="tel" class="form-contact-input" name="tel" placeholder="Telefone" /></br></div>
     <div class="col-lg-12 col-md-12 col-sm-8 col-xs-8"><textarea class="form-contact-textarea" name="conteudo" placeholder="Deixe uma mensagem" required></textarea></br></div>
     <div class="col-lg-12 col-md-12 col-sm-8 col-xs-8"><button type="submit" class="form-contact-button">Enviar</button></div>
  </form>

</div>
<div class="contato1 texto">

<h2>
 <i class="glyphicon glyphicon-envelope"> jbl@yahoo.com.br</br></i></br></br>
  <i class="glyphicon glyphicon-phone-alt"> (38) 9 9191-6733</br></i></br></br>
  <i class="glyphicon glyphicon-phone-alt"> (38) 9 9146-2065</br></i></br></br>
<h2>

</form>

</div>
</div>
