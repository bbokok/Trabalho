<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>-- Rede JBL --</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <link rel="shortcut icon"  href="/favicon.png"/>
  <meta content="" name="keywords">
  <meta content="" name="description">

  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">
  <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900|Raleway:400,300,700,900" rel="stylesheet">
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
</head>

<body id='funcionario'>
  <?php
  include "menu.php";
   ?>
 </br></br>
</div>


</div>
<div>

   <div class=row>
      <div class="col-md-4 col-lg-4 col-md-offset-4 col-lg-offset-4">
        </br>
        </br>
        </br>
        </br>
        </br>
        </br>
        </br>
        </br>
         <form role="form" ng-submit="submit()" method="POST">
            <div class=form-content>
              <p>
                <select name="select" class="btn btn-white btn-outline btn-lg btn-rounded">
                  <option value="funcionario"> Funcionario</option>
                  <option value="adm"> Administrador</option>
                </select>
              </p>
               <div class=form-group> <input type=text name="email" id="email" class="form-control input-underline input-lg" placeholder=Email> </div>
               <div class=form-group> <input type=password name="senha" id="senha" class="form-control input-underline input-lg" placeholder=Senha> </div>
            </div>
            <button type=submit class="btn btn-white btn-outline btn-lg btn-rounded">Login</button>
            <button type=clear class="btn btn-white btn-outline btn-lg btn-rounded">Limpar</button>

         </form>
      </div>
   </div>
</div>
<?php
include_once "conexao.php";
if(isset($_POST['email'])){
$senha= $_POST['senha'];
$senha = md5($senha);
$email=($_POST['email']);
$select= ($_POST['select']);
$conexao=conecta_mysql();


if ($select=='funcionario') {
  $login = conecta_mysql();
  $sql="select * from funcionario where email = '$email' and senha = '$senha'";
  $query = mysqli_query($login,$sql);
  $result = mysqli_fetch_array($query);
  if(isset($result["email"])){
    session_start();
    $_SESSION["nome"] = $result["nome"];
    header("Location:index.php");
}
else{
  echo "erro";
}
}
if ($select=='adm') {
  $login = conecta_mysql();
   $sql="select * from adm where email_adm = '$email' and senha_adm = '$senha'";
  $query = mysqli_query($login,$sql);
  $result = mysqli_fetch_array($query);
  if(isset($result["email_adm"])){
    session_start();
    $_SESSION["nome_adm"] = $result["nome_adm"];
    header("Location:login_adm.php");
}
else{
  echo "Erro";
}

}

}
?>
</body>

</html>
