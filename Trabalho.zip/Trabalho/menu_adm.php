<div class="navbar navbar-inverse navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
      <a class="navbar-brand" href="#"><i class="glyphicon glyphicon-home"></i></i> JBL</a>
    </div>
    <div class="navbar-collapse collapse">
      <ul class="nav navbar-nav navbar-right">
        <li class="active"><a href="login_adm.php">HOME</a></li>
        <li><a href="cadastro_func.php">CADASTRAR FUNCIONÁRIO</a></li>
        <li><a href="cadastro_adm.php">CADASTRAR ADM </a></li>
        <li><a href="pedido_orcamento.php">PEDIDOS DE ORÇAMENTO</a></li>
        <li><a href="logout.php">LOGOUT</a></li>

             </li>

      </ul>
    </div>
  </div>
</div>
