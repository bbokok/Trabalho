<!DOCTYPE html!>
<html lang="pt-br">
<head>
	<meta charset="utf-8"/>
	<meta name="author" content="Professor"/>
	<meta name="description" content="Descrição"/>
	<meta name="keywords" content="Palavras, chaves"/>
	<title>POOF_Notas</title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
</head>
<body id="body">

<style>
table{

  font: 100% sans-serif;
  background-color: #efe;
  border-collapse: collapse;
  empty-cells: show;
  border: 1px solid #7a7;
  margin: 0 auto;
}
td{
		text-align: center;
    font-size:20px;
}
</style>
<?php  include "includes/menu_adm.php" ?>
<div id="area-principal">
  <div id="postagem">
<?php

include("conexao.php");
$conexao = conecta_mysql();
$sql = "SELECT * FROM disciplinas";
$query = mysqli_query($conexao, $sql);
$disciplinas = array();
while($line = mysqli_fetch_array($query, MYSQLI_ASSOC)){
  $disciplinas[] = $line;
}
?>
<h2 class=novo> Disciplinas cadastradas:</h2>
 </br>
<table border="1">
<?php
foreach($disciplinas as $disciplina){
  echo "<tr> ";
  echo "<td> ".$disciplina["nome_disc"]."</td>";
  echo "</tr>";
}
?>
</div> <!-- Postagem-->
</div> <!-- Area principal-->
</body>
</html>
