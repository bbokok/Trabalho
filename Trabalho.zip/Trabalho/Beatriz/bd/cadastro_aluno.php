<!DOCTYPE html!>
<html lang="pt-br">
<head>
	<meta charset="utf-8"/>
	<meta name="author" content="Professor"/>
	<meta name="description" content="Descrição"/>
	<meta name="keywords" content="Palavras, chaves"/>
	<title>POOF_Notas</title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
</head>
<body id="body">
  <?php  include "includes/menu_adm.php" ?>
	<div id="area-principal">

			<form method="post" action="">
				<fieldset>
					<h2 class=novo> Cadastre uma novo aluno: </h2></br>
				<p>
					<label>Nome do usuario: </label>
					<input type="text" name="nome" id="nome"/>
				</p>
				<p>
					<label>Cpf: </label>
					<input type="number" name="cpf" id="cpf"/>
				</p>
				<p>
					<label>Senha: </label>
					<input type="password" name="senha" id="senha"/>
				</p>
				<p>
					<label>Endereço: </label>
					<input  type="text" name="endereco" id="endereco"/>
				</p></br>
				<input type="submit"  value="Enviar"/>
				<input type="reset" value="Limpar"/>
			</fieldset>
			</form>
				<?php
				include("conexao.php");
				if(isset($_POST['nome'])){
				$nome=$_POST['nome'];
				$senha=md5 ($_POST['senha']);
				$endereco=($_POST['endereco']);
				$cpf=$_POST['cpf'];

				$conexao= conecta_mysql();

				$sql="insert into alunos(nome,senha,cpf,endereco)
				values ('$nome','$senha','$cpf','$endereco')";

				if(mysqli_query($conexao,$sql)){
					echo "<div id='postagem'>";
					print "Aluno cadastrado com sucesso!";
					echo "</div>";
			}
			else{
				echo "<div id='postagem'>";
				echo "Erro ao cadastrar aluno!";
				echo "</div>";
			}
			}
				?>
			 <!-- Postagem-->


	</div> <!-- Area principal-->
</body>
</html>
