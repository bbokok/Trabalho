<?php session_start() ?>
<!DOCTYPE html!>
<html lang="pt-br">
<head>
	<meta charset="utf-8"/>
	<meta name="author" content="Professor"/>
	<meta name="description" content="Descrição"/>
	<meta name="keywords" content="Palavras, chaves"/>
	<title>POOF_Notas</title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
</head>
<body id="body">
  <?php  include "includes/menu_aluno.php"?>
	<div id="area-principal">
		<div id="postagem_alunos">
    	<?php
			include('funcao.php');
			$hora = horacerta();
			print "$hora, ".$_SESSION['nome'].". Estas são as disciplinas que você está cadastrad@.";
			print "<br/>";
      ?>
		</div>
	</br>

		<?php
			include("conexao.php");
			$conexao = conecta_mysql();
			$cod_aluno= $_SESSION["matricula"];
			$sql = "SELECT * FROM `matricula_aluno` JOIN disciplinas ON cod_disciplina = disciplinas.COD_DISC WHERE cod_aluno = $cod_aluno";
			$query = mysqli_query($conexao, $sql);
			$disciplinas = array();
			while($line = mysqli_fetch_array($query, MYSQLI_ASSOC)){
				$disciplinas[] = $line;
			}
			?>

			<table class=clear border="1" id="tabela">
			<td>Disciplinas:</td>
			<td>Carga Horária:</td>

			<?php
			foreach($disciplinas as $disciplina){
				echo "<tr> ";
				echo "<td> ".$disciplina["nome_disc"]."</td>";
				echo "<td>".$disciplina["carga_hor"]."</td>";
				echo "</tr>";
			}
			?>
	</div>
  </div>
  </body>
  </html>
