<?php
function horacerta(){
  $servidor = date("H:i");
  if ($servidor>='06:00' and $servidor<'12:00' ) {
    $bom = "Bom Dia";
  }

  if ($servidor>='12:00' and $servidor<='18:00' ) {
    $bom = "Boa Tarde";
  }

  if ($servidor>'18:00' and $servidor<='00:00' ) {
    $bom = "Boa Noite";
  }

  if ($servidor>'00:00' and $servidor<='06:00' ) {
    $bom = "Boa Madrugada";
  }
  return $bom;
}

 ?>
