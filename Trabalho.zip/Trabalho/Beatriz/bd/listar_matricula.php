<!DOCTYPE html!>
<html lang="pt-br">
<head>
	<meta charset="utf-8"/>
	<meta name="author" content="Professor"/>
	<meta name="description" content="Descrição"/>
	<meta name="keywords" content="Palavras, chaves"/>
	<title>POOF_Notas</title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
</head>
<body id="body">
<style>
table{

  font: 100% sans-serif;
  background-color: #efe;
  border-collapse: collapse;
  empty-cells: show;
  border: 1px solid #7a7;
  margin: 0 auto;
}
td{
		text-align: center;
    font-size:20px;
}
</style>
<?php  include "includes/menu_adm.php" ?>
<div id="area-principal">

    <form method="post">
    <fieldset>
      <label> Digite o codigo da disciplina que deseja pesquisar: </label>
      <input type="text" name="cod_disciplina"/><br/> <br/>

      <input type="submit" value="enviar"/>
      <input type="reset" value="limpar"/>
    </fieldset>
<table border="3">
<?php
if (isset($_POST["cod_disciplina"])) {
	$cod = $_POST["cod_disciplina"];
	echo "<tr>
		<th colspan='2'>$cod</th>
		</tr><tr>
		<th>Nome</th>
		<th>Matrícula</th>
	</tr>";
	include("conexao.php");
	$conexao = conecta_mysql();
	// $sql = "SELECT alunos.nome, alunos.matricula FROM disciplinas INNER JOIN alunos ON matricula = alunos.matricula
  //   WHERE COD_DISC = '$cod'";
	$sql = "SELECT alunos.nome, alunos.matricula FROM matricula_aluno JOIN alunos ON cod_aluno = alunos.matricula WHERE cod_disciplina = '$cod'";
	$query = mysqli_query($conexao, $sql);
	$disciplinas = array();
	while($line = mysqli_fetch_array($query, MYSQLI_ASSOC)){
  	$disciplinas[] = $line;
	}
foreach($disciplinas as $disciplina){
  echo "<tr> ";
  echo "<td> ".$disciplina["nome"]."</td>";
	echo "<td> ".$disciplina["matricula"]."</td>";
  echo "</tr>";
}
}

?>
</table>

<?php
SESSION_START();
?>

</div> <!-- Area principal-->
</body>
</html>
