<?php
function horacerta(){
  $servidor = date("H");
  if ($servidor>=6 and $servidor<12 ) {
    $bom = "Bom Dia ";
  }

  if ($servidor>=12 and $servidor<=18 ) {
    $bom = "Boa Tarde ";
  }

  if ($servidor>18 and $servidor<=0 ) {
    $bom = "Boa Noite ";
  }
  if ($servidor>0 and $servidor<=6 ) {
    $bom = "Boa Madrugada ";
  }
}
?>
