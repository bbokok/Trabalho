<!DOCTYPE html!>
<html lang="pt-br">
<head>
	<meta charset="utf-8"/>
	<meta name="author" content="Professor"/>
	<meta name="description" content="Descrição"/>
	<meta name="keywords" content="Palavras, chaves"/>
	<title>POOF_Notas</title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
</head>
<body id="body">
  <?php  include "includes/menu_adm.php" ?>
	<div id="area-principal">

			<form method="post" action="">
				<fieldset>
					<h2 class=novo>        Cadastre uma nova disciplina:</h2>
					 </br>
				<p>
					<label>Disciplina: </label>
					<input type="text" name="nome_disc" id="nome_disc"/>
				</p>
				<p>
					<label>Código: </label>
					<input type="number" name="cod_disc" id="COD_DISC"/>
				</p>
				<p>
					<label>Carga horária: </label>
					<input type="number" name="carga_hor" id="carga_hor"/>
				</p>
				<input type="submit" value="enviar"/>
				<input type="reset" value="limpar"/>
			</fieldset>
			</form>
			<?php
			include("conexao.php");
			if(isset($_POST['nome_disc'])){
			$nome_disc=$_POST['nome_disc'];
			$carga_hor=($_POST['carga_hor']);
      $cod_disc=($_POST['COD_DISC']);

			$conexao= mysqli_connect('localhost','root','root','beatriz_phpbd');

			$sql="insert into disciplinas(nome_disc,carga_hor,COD_DISC)
			values ('$nome_disc','$carga_hor','$cod_disc')";

			if( mysqli_query($conexao, $sql) ){
        echo"<div id='postagem'>";
				echo "Disciplina cadastrada com sucesso!";
				echo "</div>";
			}else{
				echo "<div id='postagem'>";
				echo "Erro ao cadastrar disciplina!";
				echo "</div>";
			}
		}
			?>
		</div> <!-- Postagem-->
	</div> <!-- Area principal-->
</body>
</html>
