<!DOCTYPE html!>
<html lang="pt-br">
<head>
	<meta charset="utf-8"/>
	<meta name="author" content="Professor"/>
	<meta name="description" content="Descrição"/>
	<meta name="keywords" content="Palavras, chaves"/>
	<title>POOF_Notas</title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
</head>
<body id="body">
<style>
table{

	background-color: #ffff;
	/*border-collapse: collapse;
	empty-cells: show;
	border: 1px solid #7a7;
	margin: 0 auto;*/
}
td{
		font-size:20px;
		text-align: center;
}
</style>
  <?php  include "includes/menu_adm.php" ?>
	<div id="area-principal">
		<div id="postagem_alunos">
			<?php
			include("conexao.php");
			$conexao = conecta_mysql();
			$sql = "SELECT * FROM alunos";
			$query = mysqli_query($conexao, $sql);
			$alunos = array();
			while($line = mysqli_fetch_array($query, MYSQLI_ASSOC)){
				$alunos[] = $line;
			}
			?>
			<h2 class=novo> Alunos cadastrados: </h2>
			<table border="1">
			<td>   Alunos:  </br></td>

			<?php
			foreach($alunos as $aluno){
				echo "<tr></br>";
				echo "<td>".$aluno["nome"]."</td>";
				echo "</tr>";
			}
			?>
		</table>
		</div> <!-- Postagem-->
	</div> <!-- Area principal-->
</body>
</html>
