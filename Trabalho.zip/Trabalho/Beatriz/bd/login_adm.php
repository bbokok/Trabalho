<!DOCTYPE html!>
<html lang="pt-br">
<head>
	<meta charset="utf-8"/>
	<meta name="author" content="Professor"/>
	<meta name="description" content="Descrição"/>
	<meta name="keywords" content="Palavras, chaves"/>
	<title>POOF_Notas</title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
</head>
<body id="body">
  <?php  include "includes/menu_adm.php"?>
	<div id="area-principal">
		<br><br><br>
		<div id="postagem">

			<?php
echo $_POST["nome"]."<br>";
echo $_POST["email"]."<br>";
echo $_POST["nome"]."<br>";
echo $_POST["nome"]."<br>";
 ?>

    </div>

  </div>
  </body>
  </html>
