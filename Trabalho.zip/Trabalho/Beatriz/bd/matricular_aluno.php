<?php session_start() ?>
<!DOCTYPE html!>
<html lang="pt-br">
<head>
	<meta charset="utf-8"/>
	<meta name="author" content="Professor"/>
	<meta name="description" content="Descrição"/>
	<meta name="keywords" content="Palavras, chaves"/>
	<title>POOF_Notas</title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
</head>
<body id="body">
  	<?php include "includes/menu_adm.php" ?>

<form method="post">

<fieldset>
  <label> Digite o codigo do aluno que deseja cadastrar: </label>
  <input type="number" name="cod_aluno"/><br/> <br/>

  <label> Digite o codigo da disciplina em que deseja cadastrar o aluno: </label>
  <input type="number" name="cod_disciplina"/><br/> <br/>

  <input type="submit" value="Enviar"/>
  <input type="reset" value="Limpar"/>
</fieldset>
</form>

<div id="area-principal">
  <div id="postagem">
    <?php
    include("conexao.php");
    $conexao = conecta_mysql();
    $sql = "SELECT * FROM alunos";
    $query = mysqli_query($conexao, $sql);
    $alunos = array();
    while($line = mysqli_fetch_array($query, MYSQLI_ASSOC)){
      $alunos[] = $line;
    }
    ?>
		<h2 class=novo> Alunos cadastrados:</h2>
		 </br>
    <table border="1">
		<td></br>  Alunos:</br></td>
    <td></br>Matricula:</br></td>

    <?php
    foreach($alunos as $aluno){
      echo "<tr>";
      echo "<td>".$aluno["nome"]."</td>";
      echo "<td>".$aluno["matricula"]."</td>";
      echo "</tr>";
    }
    ?>
  </table> <br/>
<?php
  $sql = "SELECT * FROM disciplinas";
  $query = mysqli_query($conexao, $sql);
  $disciplinas = array();
  while($line = mysqli_fetch_array($query, MYSQLI_ASSOC)){
    $disciplinas[] = $line;
  }
  ?>
	<h2 class=novo> Disciplinas cadastradas:</h2>
	 </br>
  <table border="1">
  <td>Disciplinas:</td>
  <td>Código da Disciplina:</td>
  <?php
  foreach($disciplinas as $disciplina){
    echo "<tr> ";
    echo "<td> ".$disciplina["nome_disc"]."</td>";
    echo "<td>".$disciplina["COD_DISC"]."</td>";
    echo "</tr>";
  }
  ?>
</table>
  </div> <!-- Postagem-->
</div> <!-- Area principal-->

<?php
if (isset($_POST['cod_aluno'])) {
  $cod_aluno= $_POST['cod_aluno'];
  $cod_disciplina= $_POST['cod_disciplina'];

	$sql1 = "SELECT * FROM alunos WHERE matricula='$cod_aluno'";
	$sql2 = "SELECT * FROM disciplinas WHERE COD_DISC='$cod_disciplina'";
	if ($query1 = mysqli_query($conexao, $sql1) AND $query2 = mysqli_query($conexao, $sql2)) {
		$query1 = mysqli_fetch_assoc($query1);
		$query2 = mysqli_fetch_assoc($query2);
		if(isset($query1["matricula"]) and isset($query2["COD_DISC"])){

			$sql= "INSERT INTO matricula_aluno (cod_aluno,cod_disciplina) VALUES ('$cod_aluno','$cod_disciplina')";
		  // echo $sql;
		  if ($query = mysqli_query($conexao, $sql)) {
		    print "Matricula bem sucedida!!";
		  }else{
				print "Matricula mal sucedida!!";
			}


		}else{
			print "Código de Usuário ou Disciplina Inválido!";
		}
	}
}
 ?>
</body>
</html>
