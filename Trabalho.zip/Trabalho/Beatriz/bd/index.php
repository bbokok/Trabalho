<!DOCTYPE html!>
<html lang="pt-br">
<head>
	<meta charset="utf-8"/>
	<meta name="author" content="Professor"/>
	<meta name="description" content="Descrição"/>
	<meta name="keywords" content="Palavras, chaves"/>
 <title>POOF_Notas</title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
</head>
<body id="body">
	<?php  include "includes/menu.php" ?>
	<div id="area-principal">

			<form method="post" action="">
				<fieldset>
				<p>
          <select name="select">
						<option value="aluno"> Aluno</option>
						<option value="administrador"> Administrador</option>
          </select>
				</p>
				<p>
					<label>Cpf: </label>
					<input type="number" name="cpf" id="cpf"/>
				</p>
				<p>
					<label>Senha: </label>
					<input type="password" name="senha" id="senha"/>
				</p>
				<input type="submit" value="enviar"/>
				<input type="reset" value="limpar"/>
			</fieldset>
			</form>


			<?php
			if(isset($_POST['cpf'])){
			$senha= $_POST['senha'];
			$senha = md5($senha);
      $cpf=($_POST['cpf']);
      $select= ($_POST['select']);
			include "conexao.php";
			$conexao=conecta_mysql();

      if ($select=='aluno') {
        $login = conecta_mysql();
  			$sql="select * from alunos where cpf = '$cpf' and senha = '$senha'";
        $query = mysqli_query($login,$sql);
        $result = mysqli_fetch_array($query);
  			if(isset($result["cpf"])){
					session_start();
          $_SESSION["matricula"] = $result["matricula"];
          $_SESSION["nome"] = $result["nome"];
          header("Location:login_aluno.php");
      }
			else{
        echo "Erro";
      }
      }
      if ($select=='administrador') {
				$login = conecta_mysql();
  			$sql="select * from administrador where cpf_adm = '$cpf' and senha_adm = '$senha'";
        $query = mysqli_query($login,$sql);
        $result = mysqli_fetch_array($query);
  			if(isset($result["cpf_adm"])){
					session_start();
          $_SESSION["cod_adm"] = $result["cod_adm"];
          $_SESSION["nome_adm"] = $result["nome_adm"];
          header("Location:login_adm.php");
      }
			else{
        echo "Erro";
      }

      }

		}
			?>

	</div> <!-- Area principal-->
</body>
</html>
