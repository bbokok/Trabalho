
<div id="navegacao">
</br>
	<h1 id="logo"> <span class="verde">POOF</span>_<span class="verde">Notas</span> </h1>
</div>
<div id="menu">

      </br><a href="matricular_aluno.php">Matricular Aluno</a></br></br>
		  </br><a href="cadastro_aluno.php">Cadastrar aluno</a></br></br>
	    </br><a href="cadastro_disc.php">Cadastrar disciplina</a></br></br>
		  </br><a href="cadastro_adm.php">Cadastrar Adm</a></br></br>
		  </br><a href="listar_alunos.php">Listar Aluno</a></br></br>
	    </br><a href="listar_disc.php">Listar Disciplinas</a></br></br>
		  </br><a href="listar_matricula.php">Listar Matricula</a></br></br>

			</br><a href="logout.php">Logout</a>
		</div>
