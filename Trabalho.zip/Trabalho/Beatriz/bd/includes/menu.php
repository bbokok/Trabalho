
<div id="navegacao">
	</br>
<h1 id="logo"> <span class="verde">POOF</span>_<span class="verde">Notas</span> </h1>
	<div id="area">
		</div>
</div>
</br>
<div id="menu_login"></br>
	<a href="index.php">Login</a>
</div>
