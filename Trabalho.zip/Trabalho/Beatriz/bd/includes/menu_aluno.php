<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
	</head>
	<body>
<div id="navegacao">
	<h1 id="logo"> <span class="verde">POOF</span>_<span class="verde">Notas</span> </h1>
	<div id="area">

	</div>
	</div>
</br>
<div id="menu_login">
	<a href="logout.php">Logout</a>
</div>
</body>
</html>
