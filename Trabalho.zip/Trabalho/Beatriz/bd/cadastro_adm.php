<!DOCTYPE html!>
<html lang="pt-br">
<head>
	<meta charset="utf-8"/>
	<meta name="author" content="Professor"/>
	<meta name="description" content="Descrição"/>
	<meta name="keywords" content="Palavras, chaves"/>
	<title>POOF_Notas</title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
</head>
<body id="body">
  <?php  include "includes/menu_adm.php" ?>
	<div id="area-principal">

			<form method="post" action="">
				<fieldset>
					<h2 class=novo> Cadastre uma novo administrador: </h2></br>
				<p>
					<label>Nome do Administrador: </label>
					<input type="text" name="nome" id="nome"/>
				</p>
				<p>
					<label>Cpf: </label>
					<input type="number" name="cpf" id="cpf"/>
				</p>
				<p>
					<label>Senha: </label>
					<input type="password" name="senha" id="senha"/>
				</p></br>
				<input type="submit" value="enviar"/>
				<input type="reset" value="limpar"/>
			</fieldset>
			</form>


			<?php
			include("conexao.php");
			if(isset($_POST['nome'])){
			$nome=$_POST['nome'];
			$senha=md5 ($_POST['senha']);
      $cpf=$_POST['cpf'];

			$conexao= conecta_mysql();

			$sql="insert into administrador(nome_adm,senha_adm,cpf_adm)
			values ('$nome','$senha','$cpf')";

			if(mysqli_query($conexao,$sql)){
				print "Administrador cadastrado com sucesso";
		}
		else{
      echo "Deu ruim!!";
    }
	}
			?>

	</div> <!-- Area principal-->
</body>
</html>
