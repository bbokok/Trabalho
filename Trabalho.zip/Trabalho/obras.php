<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>-- Rede JBL --</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <link rel="shortcut icon"  href="/favicon.png"/>

  <meta content="" name="description">

  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">
  <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900|Raleway:400,300,700,900" rel="stylesheet">
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">

  <script src="jquery-1.9.1.min.js" type="text/javascript"></script>
  <script src="coin-slider.min.js" type="text/javascript"></script>
  <link href="coin-slider-styles.css" rel="stylesheet" type="text/css">

</head>

<body>

  <?php
  include "menu.php";
   ?>
</br></br></br>

  <div class="jumbotron">
    <div class="container text-center">
      <h1>OBRAS</h1>
    </div>
  </div>

  <div class="container-fluid bg-3 text-center">
    <div class="row">
      <div class="col-sm-3">
        <p>Some text..</p>
        <img class="formata_img "src="https://www.epi-tuiuti.com.br/wp-content/uploads/2014/02/1-construcao-civil.jpg" class="img-responsive" style="width:100%" alt="Image">
      </div>
      <div class="col-sm-3">
        <p>Some text..</p>
        <img  class="formata_img "src="https://st.depositphotos.com/2403851/3881/i/450/depositphotos_38817985-stock-photo-construction-worker.jpg" class="img-responsive" style="width:100%" alt="Image">
      </div>
      <div class="col-sm-3">
        <p>Some text..</p>
        <img class="formata_img " src="https://centrourbano.com/revista/wp-content/uploads/El-diciembre-aument%C3%B3-0.4-el-valor-de-la-producci%C3%B3n-de-empresas-constructoras-735x400.jpg" class="img-responsive" style="width:100%" alt="Image">
      </div>
      <div class="col-sm-3">
        <p>Some text..</p>
        <img class="formata_img "src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQxyzi8qRRyrO5Y6HIhXaKRIY6MeHmCuaY1GPHdPJa0BdIHYSEZ4g" class="img-responsive" style="width:100%" alt="Image">
      </div>
    </div>
  </div><br>

  <div class="container-fluid bg-3 text-center">
    <div class="row">
      <div class="col-sm-3 ">
        <p>Some text..</p>
        <img class="formata_img " src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR3ERSwtmBE9mARl1O836M-SXW15CtL1UMCYch7ySIr4CPtwlCR" class="img-responsive" style="width:100%" alt="Image">
      </div>
      <div class="col-sm-3">
        <p>Some text..</p>
        <img class="formata_img "src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTtEJQuT0v6Dmr-3oFc_McBFo5L_uQ0oenqIqaZfSVq-lxloZfh" class="img-responsive" style="width:100%" alt="Image">
      </div>
      <div class="col-sm-3">
        <p>Some text..</p>
        <img class="formata_img "src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQR48sAEyc1ig9pm6loj4pLbhL7_eId9-YoMTtyO0uLtovt0nr1" class="img-responsive" style="width:100%" alt="Image">
      </div>
      <div class="col-sm-3">
        <p>Some text..</p>
        <img class="formata_img "src="http://static5.kpmconstrucoes.com.br/files/2013/05/casa-bloco-kpm-construcoes.jpg" class="img-responsive" style="width:100%" alt="Image">
      </div>
    </div>
  </div><br><br>

  </footer>

     <div id="copyrights">
       Create by Beatriz
     </div>
</body>
</html>
