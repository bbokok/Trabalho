<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title> -- Rede JBL --</title>
  <link rel="shortcut icon"  href="/favicon.png"/>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900|Raleway:400,300,700,900" rel="stylesheet">
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">

</head>

<body>
  <?php
  include "menu.php";
   ?>
</br></br></br>
<div class="container text-center">
  <h1>Faça seu orçamento</h1>
</div>
  <div class="container">
  <form class="form-contact" method="post" tabindex="1">
     <input type="text" class="form-contact-input" name="nome" placeholder="Nome" required />
     <input type="email" class="form-contact-input" name="email" placeholder="Email" required />
     <input type="number" class="form-contact-input" name="cpf" placeholder="CPF" required />
     <input type="tel" class="form-contact-input" name="tel" placeholder="Telefone" />
    <h4><b>Tipo de serviço: <select name="select" class="btn btn-white btn-outline btn-lg btn-rounded">
       <option value="obras"> Obras</option>
       <option value="contrucao_civil"> Construção Civil</option>
       <option value="projeto"> Projeto arquitetonico</option>
       <option value="aluguel"> Aluguel de máquinas</option><b></h4>

     </select></br></br>
     <textarea class="form-contact-textarea" name="conteudo" placeholder="Deixe aqui algumas especificações..." required></textarea>
     <button type="submit" class="form-contact-button">Enviar</button>
  </form>

  <?php
  if(isset($_POST["email"])){
    $email = $_POST["email"];
    $nome = $_POST["nome"];
    $tel = $_POST["tel"];
    $select =$_POST["select"];
    $especificacao = $_POST["conteudo"];
    $cpf = $_POST["cpf"];

    include_once "conexao.php";
    $conexao=conecta_mysql();

    $sql = "INSERT INTO orcamento (nome, email, cpf, telefone, especificacao, tipo)
    values ('$nome', '$email', '$cpf', '$tel','$especificacao' , '$select')";

    if(mysqli_query($conexao, $sql)){
      echo "<script>alert('Confirmado')</script>";
    }
  }
   ?>
</div>
</div>
</body>
</html>
