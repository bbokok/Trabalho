-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 28-Nov-2018 às 12:38
-- Versão do servidor: 5.7.19-0ubuntu0.16.04.1
-- PHP Version: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jbl`
--
CREATE DATABASE IF NOT EXISTS `jbl` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `jbl`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `adm`
--

CREATE TABLE IF NOT EXISTS `adm` (
  `nome_adm` varchar(60) DEFAULT NULL,
  `cpf_adm` bigint(20) DEFAULT NULL,
  `senha_adm` varchar(32) DEFAULT NULL,
  `email_adm` varchar(60) DEFAULT NULL,
  `id_adm` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id_adm`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `adm`
--

INSERT INTO `adm` (`nome_adm`, `cpf_adm`, `senha_adm`, `email_adm`, `id_adm`) VALUES
('bia', 123, 'bia', NULL, 1),
('Bia', 123, '202cb962ac59075b964b07152d234b70', 'b@b', 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionarios`
--

CREATE TABLE IF NOT EXISTS `funcionarios` (
  `nome` varchar(60) DEFAULT NULL,
  `senha` varchar(32) DEFAULT NULL,
  `cpf` bigint(20) DEFAULT NULL,
  `endereco` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `orcamento`
--

CREATE TABLE IF NOT EXISTS `orcamento` (
  `id` int(13) NOT NULL AUTO_INCREMENT,
  `nome` varchar(90) NOT NULL,
  `email` varchar(90) NOT NULL,
  `cpf` bigint(17) NOT NULL,
  `telefone` int(25) NOT NULL,
  `especificacao` varchar(500) DEFAULT NULL,
  `tipo` enum('obras','projeto-arquitetonico','construcao-civil','aluguel-de-maquinas') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `orcamento`
--

INSERT INTO `orcamento` (`id`, `nome`, `email`, `cpf`, `telefone`, `especificacao`, `tipo`) VALUES
(1, 'Mag', 'm@g', 25132132, 23132132, '', NULL),
(2, 'Mag', 'm@g', 25132132, 23132132, 'obras', NULL),
(3, 'Mag', 'm@g', 25132132, 23132132, 'dsadsadsasad', 'obras'),
(4, 'fdhgdhg', 'g@g', 434343, 565868, 'djgfkdgkjhlkgjgjfdglkj', 'obras');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
