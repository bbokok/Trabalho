<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title> -- Rede JBL --</title>
  <link rel="shortcut icon"  href="/favicon.png"/>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900|Raleway:400,300,700,900" rel="stylesheet">
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">

</head>

<body>
  <?php
  include "menu.php";
   ?>
</br></br></br>
<!-- <div class="circulo img-responsive col-lg-4 col-lg-offset-2 col-xs-4">
  		<div class="img" style="background-color: ("blue");"></div>

  		<div class="dentro">
      </br></br></br>  </br></br></br>  </br></br>
  <div id="botao" >
  </br>oii
  </div>

        </div>

  </div> -->

  <!-- <div class="circulo img-responsive col-lg-4 col-lg-offset-2 col-xs-4">
    		<div class="img" style="background-image:url('http://1.bp.blogspot.com/-a632cWhzU7E/VNT0MncCZRI/AAAAAAAAAeo/a6yrdo08akQ/s1600/02.jpg');"></div>
    		<div class="dentro">
              </br></br></br>  </br></br></br>  </br></br>
          <div id="botao" >
          </br>    oii
          </div>
        </div>

    </div>

    <div class="circulo img-responsive col-lg-4 col-lg-offset-2 col-xs-4">
      		<div class="img" style="background-image:url('http://1.bp.blogspot.com/-a632cWhzU7E/VNT0MncCZRI/AAAAAAAAAeo/a6yrdo08akQ/s1600/02.jpg');"></div>

      		<div class="dentro">
          </br></br></br>  </br></br></br>  </br></br>
      <div id="botao" >
      </br>oii
      </div>

            </div>

      </div> -->

</body>
</html>
