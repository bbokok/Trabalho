<div class="navbar navbar-inverse navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
      <a class="navbar-brand" href="#"><i class="glyphicon glyphicon-home"></i></i> JBL</a>
    </div>
    <div class="navbar-collapse collapse">
      <ul class="nav navbar-nav navbar-right">
        <li class="active"><a href="index.php">HOME</a></li>
        <li><a href="obras.php">OBRAS</a></li>
        <li><a href="quemsomos.php">QUEM SOMOS</a></li>
        <li><a href="orcamento.php">ORÇAMENTOS</a></li>
        <li><a href="funcionarios.php">PÁGINA DO FUNCIONÁRIO</a></li>


             </li>

      </ul>
    </div>
  </div>
</div>
